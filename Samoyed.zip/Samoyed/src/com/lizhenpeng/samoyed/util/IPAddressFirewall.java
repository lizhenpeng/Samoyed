package com.lizhenpeng.samoyed.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.lizhenpeng.samoyed.core.DnsPacket;
import com.lizhenpeng.samoyed.core.DnsResponse;

public class IPAddressFirewall implements Firewall {
	
	//------------------------------------------------------------------------------- Instance Variables
	
	private static int ThreadWorkingDuration = 60000;
	private static int recoverDuration = 120000;
	private Map<String,RequestInfo> hash = Collections.synchronizedMap(new HashMap<String,RequestInfo>());
	
	//�����ػ��߳�
	public IPAddressFirewall() {
		guardThread();
	}
	
	public synchronized boolean accpet(DnsPacket packet, DnsResponse response) {
		String address = packet.getAddress();
		if(hash.containsKey(address)) {
			RequestInfo info = hash.get(address);
			return info.toLimit();
		}
		else {
			hash.put(address, new RequestInfo(System.currentTimeMillis()));
			return true;
		}
	}	
	
	public void guardThread() {
		Thread deamon = new Thread(new clearThread());
		deamon.setDaemon(true);
		deamon.start();
	}
	
	//------------------------------------------------------------------------------ ��¼ʱ��
	
	private class clearThread implements Runnable{
		//��ʱ����������
		public void run() {
			while(true) {
				for(Map.Entry<String,RequestInfo> variable :hash.entrySet()) {
					String address = variable.getKey();
					RequestInfo info = hash.get(address);
					info.clearRequestNum();
					if(System.currentTimeMillis() - info.getLastTime() > recoverDuration) {
						hash.remove(address);
					}
				}
				try {
					Thread.sleep(ThreadWorkingDuration);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	private class RequestInfo{
		
		private int RequestNum = 1;
		private int limit = 20;
		private long lastRequestTime = 0;
		
		public RequestInfo(long requestTime) {
			this.lastRequestTime = requestTime;
		}
		
		public long getLastTime() {
			return lastRequestTime;
		}
		
		public void clearRequestNum() {
			RequestNum = 1;
		}
		
		public boolean toLimit() {
			if(RequestNum >= limit) {
				return false;
			}
			else {
				RequestNum++;
				return true;
			}
		}
		
	}
}
