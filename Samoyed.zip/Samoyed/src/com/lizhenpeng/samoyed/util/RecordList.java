package com.lizhenpeng.samoyed.util;

import java.util.HashMap;
import java.util.List;

public class RecordList {
	
	//--------------------------------------------------------------------- Instance Variables
	
	private static RecordList list;
	private static Object Lock = new Object();
	private HashMap<String,Relation> hash = new HashMap<>();
	
	//--------------------------------------------------------------------- Public Methods
	
	private RecordList() {
		//˽�еĹ��캯��
	}
	
	public synchronized void addCord(String domain,RecordType kind,String address) {
		if(!hash.containsKey(domain)) {
			Relation relation = new Relation();
			relation.addRecord(kind, address);
			hash.put(domain, relation);
			return;
		}
		Relation relation = hash.get(domain);
		relation.addRecord(kind, address);
	}
	
	public synchronized String getAddress(String domain,RecordType kind) {
		if(hash.containsKey(domain)) {
			Relation relation = hash.get(domain);
			return relation.getAddress(kind);
		}
		return null;
	}
	
	public synchronized void deleteRecord(String domain,RecordType type,String address) {
		if(hash.containsKey(domain)) {
			Relation relation = hash.get(domain);
			relation.deleteRecord(type, address);
		}
	}
	
	public synchronized boolean containsRecord(String domain,RecordType type,String address) {
		if(hash.containsKey(domain)) {
			Relation relation = hash.get(domain);
			return relation.containsRecordKind(type,address);
		}
		return false;
	}
	
	public synchronized List<String> getAllAddress(String domain,RecordType type){
		if(hash.containsKey(domain)) {
			Relation relation = hash.get(domain);
			return relation.getAllAddress(type);
		}
		return null;
	}
	
	public static RecordList getInstance() {
		synchronized(Lock) {
			if(list == null) {
				list = new RecordList();
			}
			return list;
		}
	}
	
}
