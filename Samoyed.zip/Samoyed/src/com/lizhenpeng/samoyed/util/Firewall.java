package com.lizhenpeng.samoyed.util;

import com.lizhenpeng.samoyed.core.DnsPacket;
import com.lizhenpeng.samoyed.core.DnsResponse;

public interface Firewall {
	public boolean accpet(DnsPacket packet,DnsResponse response);
}
