package com.lizhenpeng.samoyed.util;

public enum RecordType {
	
	//------------------------------------------------------------------------------------ Enum Vlaues
	
	A,NS,CNAME,SOA,WKS,RTP,HINFO,MX,AAAA,AXFR,ANY;
	
	//----------------------------------------------------------------------------------- Properties
	
	public static RecordType getType(int num) {
		switch(num) {
			case 1:return A;
			case 2:return NS;
			case 5:return CNAME;
			case 6:return SOA;
			case 11:return WKS;
			case 12:return RTP;
			case 13:return HINFO;
			case 15:return MX;
			case 28:return AAAA;
			case 252:return AXFR;
			case 255:return ANY;
			default:return A;
		}
	}	
	
	public static int getValue(RecordType type) {
		switch(type) {
		case A:return 1;
		case NS:return 2;
		case CNAME:return 5;
		case SOA:return 6;
		case WKS:return 11;
		case RTP:return 12;
		case HINFO:return 13;
		case MX:return 15;
		case AAAA:return 28;
		case AXFR:return 252;
		case ANY:return 255;
		default:return 1;
		}
	}
}
