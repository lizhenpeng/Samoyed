package com.lizhenpeng.samoyed.util;

import com.lizhenpeng.samoyed.core.DnsPacket;
import com.lizhenpeng.samoyed.core.DnsResponse;

public interface Processer {
	public void process(DnsPacket dnsPacket,DnsResponse response);
}
