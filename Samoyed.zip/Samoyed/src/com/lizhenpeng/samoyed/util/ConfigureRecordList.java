package com.lizhenpeng.samoyed.util;

import java.io.File;

public interface ConfigureRecordList {
	public void load(File file);
}
