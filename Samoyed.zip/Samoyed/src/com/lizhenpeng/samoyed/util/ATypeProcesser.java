package com.lizhenpeng.samoyed.util;

import java.io.IOException;
import com.lizhenpeng.samoyed.core.DnsPacket;
import com.lizhenpeng.samoyed.core.DnsResponse;

//Ĭ�ϵ�A���ͼ�¼������
public class ATypeProcesser implements Processer{
	
	public void process(DnsPacket dnsPacket, DnsResponse response) {
		try {
			
			RecordList list = RecordList.getInstance();
			String domain = dnsPacket.getDomain();
			String address = list.getAddress(domain, RecordType.A);
			
			if(address != null) {
				response.sendIPAddress(address);
			}
			else {
				response.sendNotFoundNameRecord();
			}
		} catch (IOException e) {
			System.out.println("�������ʧ��!");
			e.printStackTrace();
		}
	}
}
