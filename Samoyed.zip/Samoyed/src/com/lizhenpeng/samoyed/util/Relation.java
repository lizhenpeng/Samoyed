package com.lizhenpeng.samoyed.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Relation {
	
	//--------------------------------------------------------------------- Instance Variables
	
	private HashMap<RecordType,CircleList> hash = new HashMap<>();
	
	//--------------------------------------------------------------------- Public Methods
	
	public boolean containsRecordKind(RecordType kind,String address) {
		if(hash.containsKey(kind)) {
			CircleList list = hash.get(kind);
			return list.contains(address);
		}
		return false;
	}
	
	public String getAddress(RecordType kind) {
		if(hash.containsKey(kind)) {
			CircleList list = hash.get(kind);
			return list.getAddress();
		}
		return null;
	}
	
	//�����ض��ļ�¼
	public void addRecord(RecordType kind,String address) {
		if(!hash.containsKey(kind)) {
			CircleList list = new CircleList();
			list.add(address);
			hash.put(kind, list);
			return;
		}
		CircleList list = hash.get(kind);
		list.add(address);
	}
	
	public void deleteRecord(RecordType kind,String address) {
		if(hash.containsKey(kind)) {
			CircleList list = hash.get(kind);
			list.delete(address);
		}
	}
	
	public List<String> getAllAddress(RecordType type){
		if(hash.containsKey(type)) {
			CircleList list = hash.get(type);
			return list.getAllAddress();
		}
		return null;
	}
	
	//�ڲ���
	
	public class CircleList {
		
		//---------------------------------------------------------------- Instance Variables
		
		private int pointer = 0;
		private ArrayList<String> list = new ArrayList<>();
		private HashMap<String,Integer> log = new HashMap<>();
		
		//----------------------------------------------------------------- Public Methods
		
		public synchronized String getAddress() {
			if(list.size() > 0) {
				String address = list.get(pointer);
				pointer = (++pointer) % (list.size());
				if(!log.containsKey(address)) {
					log.put(address, 0);
				}
				else {
					int number = log.get(address);
					log.put(address, ++number);
				}
				return address;
			}
			return null;
		}
		
		public synchronized void add(String address) {
			list.add(address);
		}
		
		public void delete(String address) {
			list.remove(address);
		}
		
		public boolean contains(String address) {
			return list.contains(address);
		}
		
		public List<String> getAllAddress() {
			List<String> list = new ArrayList<>();
			for(String str : list) {
				list.add(str);
			}
			return list;
		}
	}

}
