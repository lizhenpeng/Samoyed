package com.lizhenpeng.samoyed.core;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class UDPConnector{
	
	//--------------------------------------------------------------------------------- Instance Variables
	
	private DatagramSocket socket;
	private InetAddress localAddress;
	private static int localPort = 8888;
	private int bufferSize = 1024;
	private int timeOut = 0;
	
	//--------------------------------------------------------------------------------- Properties
	
	public InetAddress getLocalAddress() {
		return socket.getLocalAddress();
	}
	
	public int getLocalPort() {
		return localPort;
	}
	
	public void setBufferSize(int size) {
		bufferSize = size;
	}
	
	public int getBufferSize() {
		return bufferSize;
	}
	
	public void setTimeOut(int time) throws SocketException {
		timeOut = time;
	}
	
	public int getTimeOut() {
		return timeOut;	
	}
	
	//����Socket����
	public DatagramSocket getSocket() {
		return socket;
	}
	
	//---------------------------------------------------------------------------------   Constructor
	
	public UDPConnector(InetAddress address,int port) throws SocketException {
		localAddress = address;
		localPort = port;
		socket = new DatagramSocket(port,address);
	}
	
	public UDPConnector(String address,int port) throws SocketException, UnknownHostException {
		this(InetAddress.getByName(address),port);
	}
	
	public UDPConnector(int port) throws UnknownHostException, SocketException {
		this("127.0.0.1",port);
	}

	//-------------------------------------------------------------------------------------- Public Methods
	
	public DatagramPacket accept() throws IOException {
		DatagramPacket responsePacket = new DatagramPacket(new byte[bufferSize],bufferSize);
		socket.setSoTimeout(timeOut);
		socket.receive(responsePacket);
		return responsePacket;
	}
	
	public void setLimitConnectionParty(InetAddress address,int port) {
		socket.connect(address,port);
	}
	
	public void setLimitConnectionParty(String address,int port) throws SocketException, UnknownHostException {
		setLimitConnectionParty(InetAddress.getByName(address),port);
	}
	
	public void destory() {
		socket.close();
	}
	
}
