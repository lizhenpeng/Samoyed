package com.lizhenpeng.samoyed.core;

import com.lizhenpeng.samoyed.dns.DnsCommon;
import com.lizhenpeng.samoyed.dns.DnsHeader;
import com.lizhenpeng.samoyed.dns.DnsQuestion;

public class DnsPacketBase {
	
	//------------------------------------------------------------------------------ Instance variables
	
	protected DnsHeader header;
	protected DnsQuestion question;
	protected DnsCommon answer;
	protected DnsCommon authority;
	protected DnsCommon additional;
	
	//------------------------------------------------------------------------------ Constructors
	
	public DnsPacketBase() {
		header = new DnsHeader();
		question = new DnsQuestion();
		answer = new DnsCommon();
		authority = new DnsCommon();
		additional = new DnsCommon();
	}
	
	//------------------------------------------------------------------------------- Public Methods
	
	public DnsHeader getHeader() {
		return header;
	}
	
	public DnsQuestion getQuestion() {
		return question;
	}
	
	public DnsCommon getAnswer() {
		return answer;
	}
	
	public DnsCommon getAuthority() {
		return authority;
	}
	
	public DnsCommon getAdditional() {
		return additional;
	}
	
	public short getID() {
		return header.getID();
	}
	
	public void setID(int id) {
		header.setID(id);
	}
	
	public int getQR() {
		return header.getFLAG().getQR();
	}
	
	public void setQR(int qr) {
		header.getFLAG().setQR(qr);
	}
	
	public int getOPCODE() {
		return header.getFLAG().getOpcode();
	}
	
	public void setOPCODE(int code) {
		header.getFLAG().setOpcode(code);
	}
	
	public int getAA() {
		return header.getFLAG().getAA();
	}
	
	public void setAA(int aa) {
		header.getFLAG().setAA(aa);
	}
	
	public int getTC() {
		return header.getFLAG().getTC();
	}
	
	public void setTC(int tc) {
		header.getFLAG().setTC(tc);
	}
	
	public int getRD() {
		return header.getFLAG().getRD();
	}
	
	public void setRD(int rd) {
		header.getFLAG().setRD(rd);
	}
	
	public int getRA() {
		return header.getFLAG().getRA();
	}
	
	public void setRA(int ra) {
		header.getFLAG().setRA(ra);
	}
	
	public int getZ() {
		return header.getFLAG().getZ();
	}
	
	public void setZ(int z) {
		header.getFLAG().setZ(z);
	}
	
	public int getRCODE() {
		return header.getFLAG().getRCODE();
	}
	
	public void setRCODE(int rcode) {
		header.getFLAG().setRCODE(rcode);
	}
	
	public short getQDCOUNT() {
		return header.getQDCOUNT();
	}
	
	public void setQDCOUNT(int count) {
		header.setQDCOUNT(count);
	}
	
	public short getANCOUNT() {
		return header.getANCOUNT();
	}
	
	public void setANCOUNT(int count) {
		header.setANCOUNT(count);
	}
	
	public short getNSCOUNT() {
		return header.getNSCOUNT();
	}
	
	public void setNSCOUNT(int count) {
		header.setNSCOUNT(count);
	}	
	
	public short getARCOUNT() {
		return header.getARCOUNT();
	}
	
	public void setARCOUNT(int count) {
		header.setARCOUNT(count);
	}
	
	public void setQuestionQNAME(byte[] buffer) {
		question.setQNAME(buffer);
	}
	
	public byte[] getQuestionQNAME() {
		return question.getQNAME();
	}
	
	public void setQuestionQTYPE(int type) {
		question.setQTYPE(type);
	}
	
	public int getQuestionQTYPE() {
		return question.getQTYPE();
	}
	
	public void setQuestionQCLASS(int classNum) {
		question.setQCLASS(classNum);
	}
	
	public int getQuestionQCLASS() {
		return question.getQCLASS();
	}
	
	public void setAnswerNAME(byte[] dataArray) {
		answer.setNAME(dataArray);
	}
	
	public byte[] getAnswerNAME() {
		return answer.getNAME();
	}
	
	public void setAnswerTYPE(int type) {
		answer.setTYPE(type);
	}
	
	public int getAnswerTYPE() {
		return answer.getTYPE();
	}
	
	public void setAnswerCLASS(int classType) {
		answer.setCLASS(classType);
	}
	
	public int getAnswerCLASS() {
		return answer.getCLASS();
	}
	
	public void setAnswerTTL(int ttl) {
		answer.setTTL(ttl);
	}
	
	public int getAnswerTTL() {
		return answer.getTTL();
	}
	
	public void setAnswerRDLENGTH(int length) {
		answer.setRDLENGTH(length);
	}
	
	public int getAnswerRDLENGTH() {
		return answer.getRDLENGTH();
	}
	
	public void setAnswerRDATA(int data) {
		answer.setRDATA(data);
	}
	
	//���صĺ���
	public void setAnswerRDATA(String data) {
		answer.setRDATA(data);
	}
	
	public int getAnswerRDATA() {
		return answer.getRDATA();
	}
	
}
