package com.lizhenpeng.samoyed.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Random;

import com.lizhenpeng.samoyed.util.RecordList;
import com.lizhenpeng.samoyed.util.RecordType;


//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
//Dns�ͻ��˴��벻����!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


public class DnsClient {
	
	//--------------------------------------------------------------------------------- Instance Variables
	
	private int bufferSize = 1024;
	private int timeOut = 10000;
	private int DnsServerPort = 53;
	private String DnsServerAddress = "8.8.8.8";
	RecordList list = RecordList.getInstance();
	
	public String getAddress(String domain,RecordType recordType) throws IOException {
		//������ʼ��������
		DataConversion cover = new DataConversion();
		DnsPacket packet = new DnsPacket();
		packet.setID(createRandomID());
		packet.setQR(0);
		packet.setOPCODE(0);
		packet.setQDCOUNT(1);
		byte[] domainByteArray = cover.createMixData(domain);
		packet.setQuestionQNAME(domainByteArray);
		packet.setQuestionQTYPE(RecordType.getValue(recordType));
		packet.setQuestionQCLASS(1);
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		out.write(packet.getHeader().toDataArray());
		out.write(packet.getQuestion().toDataArray());
		//���ܵ�һ������
		byte[] result = sendData(out.toByteArray(),DnsServerAddress,DnsServerPort);
		DnsPacket pack = new DnsPacket();
		pack.parsePacket(result);
		return domain;
	}
	
	private int createRandomID() {
		return new Random(47).nextInt();
	}
	
	public byte[] sendData(byte[] buffer,String address,int port) throws IOException {
		InetAddress dnsServerAddress = InetAddress.getByName(DnsServerAddress);
		DatagramSocket socket = new DatagramSocket(0);
		DatagramPacket requestPacket = new DatagramPacket(buffer,buffer.length,dnsServerAddress,port);
		DatagramPacket receivePacket = new DatagramPacket(new byte[bufferSize],bufferSize);
		socket.setSoTimeout(timeOut);
		socket.send(requestPacket);
		socket.receive(receivePacket);
		byte[] data = new byte[receivePacket.getLength()];
		System.arraycopy(receivePacket.getData(),receivePacket.getOffset(),data,0,receivePacket.getLength());
		return data;
	}
	
}
