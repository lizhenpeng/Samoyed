package com.lizhenpeng.samoyed.core;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import com.lizhenpeng.samoyed.util.Firewall;
import com.lizhenpeng.samoyed.util.IPAddressFirewall;
import com.lizhenpeng.samoyed.util.RecordList;

public class DnsConnector implements Runnable {
	
	//----------------------------------------------------------------------- Instance Variables
	
	private Firewall filter;
	private UDPConnector udpConnector;
	private static int localPort = 8888;
	private InetAddress localAddress;
	private int bufferSize = 1024;
	private boolean flag = false;
	private int timeOut = 0;
	private int ProcesserThreadNum = 50;
	ExecutorService service;
	
	//------------------------------------------------------------------------ Properties
	
	public Router getRouter() {
		return Router.getInstance();
	}
	
	public RecordList getRecordList() {
		return RecordList.getInstance();
	}
	
	public int getPort() {
		return localPort;
	}
	
	public void setBufferSize(int size) {
		bufferSize = size;
	}
	
	public int getBufferSize() {
		return bufferSize;
	}
	
	public void stop() {
		flag = true;
	}
	
	public boolean getFlag() {
		return flag;
	}
	
	public void setTimeOut(int time) {
		timeOut = time;
	}
	
	public int getTimeOut() {
		return timeOut;
	}
	
	public DatagramSocket getSocket() {
		return udpConnector.getSocket();
	}
	
	public void setFilter(Firewall ins) {
		filter = ins;
	}
	
	public Firewall getFilter() {
		return filter;
	}
	
	//------------------------------------------------------------------------ Constructor
	
	public DnsConnector(String address,int port) throws UnknownHostException, SocketException {
		this(InetAddress.getByName(address),port);
	}
	
	public DnsConnector(int port) throws UnknownHostException, SocketException {
		this(InetAddress.getByName("127.0.0.1"),port);
	}
	
	public DnsConnector() throws UnknownHostException, SocketException {
		this(InetAddress.getByName("127.0.0.1"),localPort);
	}
	
	public DnsConnector(InetAddress address,int port) throws UnknownHostException, SocketException {
		localPort = port;
		localAddress = address;
		udpConnector = new UDPConnector(localAddress,localPort);
		service = Executors.newFixedThreadPool(ProcesserThreadNum);
	}
	
	//------------------------------------------------------------------------ Public Methods
	
	//Router����RecordType����ָ���Ĵ�������ʼ����
	
	public synchronized void assign(DnsPacket request,DnsResponse response) {
		service.execute(new DnsProcesser(request,response));
	}
	
	public void monitoring() {
		service.execute(this);
	}
	
	public void run() {
		while(!flag) {
			try {
				udpConnector.setTimeOut(timeOut);
				udpConnector.setBufferSize(bufferSize);
				DatagramPacket packet = udpConnector.accept();
				DnsProtocolResolve handle = new DnsProtocolResolve(this,packet);
				service.execute(handle);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
}
