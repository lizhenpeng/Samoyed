package com.lizhenpeng.samoyed.core;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class DnsResponse extends DnsPacketBase {
	
	//--------------------------------------------------------------------------------- Instance Variables
	
	private DnsPacket dnsPacket;
	private DnsConnector dnsConnector;
	private DataOutputStream dataOut;
	private ByteArrayOutputStream dataSource;
	
	//--------------------------------------------------------------------------------- Instance Variables
	
	public DnsResponse() {
		dataSource = new ByteArrayOutputStream();
		dataOut = new DataOutputStream(dataSource);
	}
	
	//--------------------------------------------------------------------------------- Public Methods
	
	public void setDnsPacket(DnsPacket dnsPack) {
		dnsPacket = dnsPack;
	}

	public DnsPacket getDnsPacket() {
		return dnsPacket;
	}
	
	public void setDnsConnector(DnsConnector ctor) {
		dnsConnector = ctor;
	}
	
	
	public void writeToBuffer(byte[] array) throws IOException {
		dataOut.write(array);
	}
	
	public void send() throws IOException {
		//�̰߳�ȫ
		synchronized(dnsConnector) {
			InetAddress address = dnsPacket.getInetAddress();
			int port = dnsPacket.getPort();
			byte[] buffer = dataSource.toByteArray();
			DatagramPacket packet = new DatagramPacket(buffer,buffer.length,address,port);
			dnsConnector.getSocket().send(packet);
		}
	}
	
	//������Ӧ��֪�ͻ��˷������ڲ���������
	public void sendServerError() throws IOException {
		ByteArrayOutputStream dataStore = new ByteArrayOutputStream();
		this.setID(dnsPacket.getID());
		this.setQR(1);
		this.setAA(1);
		this.setRA(1);
		this.setRCODE(2);
		dataStore.write(this.getHeader().toDataArray());
		this.writeToBuffer(dataStore.toByteArray());
		this.send();
	}
	
	//������Ӧ��֪�ͻ��˷�����û����صĽ���
	public void sendNotFoundNameRecord() throws IOException {
		ByteArrayOutputStream dataStore = new ByteArrayOutputStream();
		this.setID(dnsPacket.getID());
		this.setQR(1);
		this.setAA(1);
		this.setRA(1);
		this.setRCODE(3);
		dataStore.write(this.getHeader().toDataArray());
		this.writeToBuffer(dataStore.toByteArray());
		this.send();
	}
	
	//������Ӧ��֪�ͻ��˷������ܾ��������
		public void sendServerRefuse() throws IOException {
			ByteArrayOutputStream dataStore = new ByteArrayOutputStream();
			this.setID(dnsPacket.getID());
			this.setQR(1);
			this.setAA(1);
			this.setRA(1);
			this.setRCODE(5);
			dataStore.write(this.getHeader().toDataArray());
			this.writeToBuffer(dataStore.toByteArray());
			this.send();
		}
	
	public void sendIPAddress(String address) throws IOException {
		//����Headerѡ��
		this.setID(dnsPacket.getID());
		this.setQR(1);
		this.setAA(1);
		this.setQDCOUNT(1);
		this.setANCOUNT(1);
		//����Answerѡ��
		this.setAnswerNAME(dnsPacket.getQuestion().getQNAME());
		this.setAnswerTYPE(1);
		this.setAnswerCLASS(1);
		this.setAnswerTTL(10);
		this.setAnswerRDLENGTH(4);
		this.setAnswerRDATA(address);
		//д��header����
		this.writeToBuffer(this.getHeader().toDataArray());
		//д��Question����		
		this.writeToBuffer(dnsPacket.getQuestion().toDataArray());
		//д��Answer����
		this.writeToBuffer(this.getAnswer().toDataArray());			
		//׼���������
		this.send();
	}
}
