package com.lizhenpeng.samoyed.core;

import java.io.IOException;

import com.lizhenpeng.samoyed.util.RecordType;

public class test {
	
	public static void main(String[] argv) throws IOException {
		DnsClient client = new DnsClient();
		client.getAddress("www.baidu.com",RecordType.A);
	}

}
