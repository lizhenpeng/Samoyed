package com.lizhenpeng.samoyed.core;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.InetAddress;

import com.lizhenpeng.samoyed.dns.DnsCommon;
import com.lizhenpeng.samoyed.util.RecordType;

public class DnsPacket extends DnsPacketBase {
	
	//---------------------------------------------------------------------------------- Instance Variables

	protected DnsResponse response;
	protected RecordType type;	
	private InetAddress addres;
	private int port;
	
	//---------------------------------------------------------------------------------- Properties
	
	public void setDnsResponse(DnsResponse response) {
		this.response = response;
	}
	
	//---------------------------------------------------------------------------------- Variables Properties

	public RecordType getDnsRecordType() {
		return RecordType.getType(question.getQTYPE());
	}
	
	//��ѯ����/��Ӧ����
	public boolean isQueryMessage() {
		if(header.getFLAG().getQR() != 0) {
			return false;
		}
		return true;
	}
	
	public void setInetAddress(InetAddress address) {
		this.addres = address;
	}
	
	public InetAddress getInetAddress() {
		return this.addres;
	}
	
	public String getAddress() {
		return this.addres.getHostAddress();
	}
	
	public void setPort(int port) {
		this.port = port;
	}
	
	public int getPort() {
		return port;
	}
	
	public String getDomain() {
		return question.getDomain();
	}
	
	public void setDomain(String domain) {
		question.setDomain(domain);
	}
	
	//------------------------------------------------------------------------------- Resolve Packet Info
	
	private void processHeader(DataInputStream InputStream) throws IOException {
		//��ȡid��ֵ
		header.setID(InputStream.readShort());
		//Flag�ı�־
		header.setFLAG(InputStream.readShort());
		//qdcount�ֶ�
		header.setQDCOUNT(InputStream.readShort());
		//����ancount
		header.setANCOUNT(InputStream.readShort());
		//����nscount
		header.setNSCOUNT(InputStream.readShort());
		//����arcount
		header.setARCOUNT(InputStream.readShort());
	}
	
	private void processQuestion(DataInputStream dataInputStream) throws IOException {
		//������ѯ������,��0x00��β,processQname���ȡ�����ֽ�
		DataConversion conversion = new DataConversion();
		//ԭʼ��Length+data����
		byte[] oriiginalData = conversion.getOriginalData(dataInputStream);
		String domain = conversion.resolveDomain(oriiginalData);
		
		//���ݹ��ڵ�Question���� QNAMEΪԭʼ�Ķ���
		question.setQNAME(oriiginalData);
		question.setDomain(domain);
		
		//������ѯ����
		question.setQTYPE(dataInputStream.readShort());
		question.setQCLASS(dataInputStream.readShort());
	}
	
	private void processDnsCommon(DnsCommon common,DataInputStream dataInputStream) throws IOException {
		//������ѯ������,��0x00��β,processQname���ȡ�����ֽ�
//		DataConversion conversion = new DataConversion();
//		byte[] dataBuffer = conversion.getOriginalData(dataInputStream);
//		common.setNAME(dataBuffer);
//		common.setTYPE(dataInputStream.readShort());
//		common.setCLASS(dataInputStream.readShort());
//		common.setTTL(dataInputStream.readShort());
//		common.setRDLENGTH(dataInputStream.readShort());
//		common.setRDATA(dataInputStream.readInt());
	}
	
	public void parsePacket(byte[] packetData) throws IOException {
		DataInputStream dataInput = new DataInputStream(new ByteArrayInputStream(packetData));
		//����Header����
		processHeader(dataInput);
		//����Question����
		if(header.getQDCOUNT() > 0) {
			processQuestion(dataInput);
		}
		//����Answer����
		if(header.getANCOUNT() > 0) {
			processDnsCommon(answer,dataInput);
		}
		//����Authority����
		if(header.getNSCOUNT() > 0) {
			processDnsCommon(authority,dataInput);
		}
		//����Additional����
		if(header.getARCOUNT() > 0) {
			processDnsCommon(additional,dataInput);
		}
	}
	
}
