package com.lizhenpeng.samoyed.core;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;

public class UDPSocket {
	
	//-------------------------------------------------------------------------- Instance Variables
	
	private static int localPort = 0;
	private DatagramSocket socket;
	private DatagramPacket requestPacket;
	private DatagramPacket responsePacket;
	private static int bufferSize = 2048;
	private int timeOut = 0;
	private InetAddress remoteAddress;
	private int remotePort = 0;
	private boolean limitConnectionParty = true;
	
	//-------------------------------------------------------------------------- Constructors
	
	public UDPSocket(DatagramSocket specifySocket) {
		socket = specifySocket;
	}
	
	public UDPSocket(int port) throws SocketException {
		localPort = port;
		socket = new DatagramSocket(localPort);
	}
	
	public UDPSocket() throws SocketException {
		this(localPort);
	}
	
	//--------------------------------------------------------------------------- Properties
	
	public void setSocket(DatagramSocket specifySocket) {
		socket.close();
		socket = specifySocket;
	}
	
	public void setRemoteAddress(String address) throws UnknownHostException {
		remoteAddress = InetAddress.getByName(address);
		requestPacket.setAddress(remoteAddress);
	}
	
	public InetAddress getRemoteAddress() {
		return remoteAddress;
	}
	
	public void setRemotePort(int port) {
		remotePort = port;
		requestPacket.setPort(remotePort);
	}
	
	public int getRemotePort() {
		return remotePort;
	}
	
	public void setTimeOut(int timeOut) throws SocketException {
		this.timeOut = timeOut;
		socket.setSoTimeout(timeOut);
	}
	
	public int getTimeOut() {
		return timeOut;
	}
	
	public void setBufferSize(int size) {
		bufferSize = size;
	}
	
	public int getBufferSize() {
		return bufferSize;
	}
	
	public void setLimitConnectionParty(boolean limit) {
		limitConnectionParty = limit;
	}
	
	public boolean getLimitConnectionParty() {
		return limitConnectionParty;
	}
	
	//--------------------------------------------------------------------------- Public Methods
	
	//����socketͨ�ŵĶ���,һ��clientֻϣ������ָ��ip�Ͷ˿ڷ��͵�������
	public void setLimitConnectionParty(InetAddress address,int port) {
		socket.connect(remoteAddress, remotePort);
	}
	
	public void setLimitConnectionParty(String address,int port) throws UnknownHostException {
		setLimitConnectionParty(InetAddress.getByName(address), port);
	}
	
	public void reliveLimit() {
		socket.disconnect();
	}
	
	public void connect(InetAddress address,int port) throws SocketException {
		remoteAddress = address;
		remotePort = port;
		requestPacket = new DatagramPacket(new byte[bufferSize],bufferSize,remoteAddress,remotePort);
		responsePacket = new DatagramPacket(new byte[bufferSize],bufferSize);
		setLimitConnectionParty(remoteAddress,remotePort);
	}
	
	public void connect(String address,int port) throws SocketException, UnknownHostException {
		connect(InetAddress.getByName(address),port);
	}
	
	public void sendData(String text) throws SocketException, IOException {
		sendData(text.getBytes());
	}
	
	public void sendData(byte[] buffer) throws SocketException,IOException {
		sendData(buffer,0,buffer.length);
	}
	
	public void sendData(byte[] buffer,int offset,int length) throws SocketException,IOException {
		requestPacket.setData(buffer,offset,length);
		socket.setSoTimeout(timeOut);
		socket.send(requestPacket);
	}
	
	public byte[] receiveData() throws IOException {
		//�߳���������
		socket.receive(responsePacket);
		int dataLength = responsePacket.getLength();
		byte[] save = new byte[dataLength];
		System.arraycopy(responsePacket.getData(), responsePacket.getOffset(),save,0,dataLength);
		return save;
	}
	
	public void destory() {
		socket.close();
	}
	
}
