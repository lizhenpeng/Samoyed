package com.lizhenpeng.samoyed.core;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.nio.ByteBuffer;

import com.lizhenpeng.samoyed.dns.DnsHeader;
import com.lizhenpeng.samoyed.dns.DnsQuestion;

public class DnsProtocolResolve implements Runnable{

	//--------------------------------------------------------------------------- Instance Variables
	
	private DnsConnector connector;
	private DatagramPacket dataGramPacket;
	private DnsPacket dnsPacket;
	private DnsResponse response;
	
	//--------------------------------------------------------------------------- Constructor
	
	public DnsProtocolResolve(DnsConnector connectors,DatagramPacket pack) {
		connector = connectors;
		dataGramPacket = pack;
		dnsPacket = new DnsPacket();
		response = new DnsResponse();
		dnsPacket.setInetAddress(dataGramPacket.getAddress());
		dnsPacket.setPort(dataGramPacket.getPort());
		response.setDnsPacket(dnsPacket);
		response.setDnsConnector(connector);
	}
	
	public void run() {
		byte[] buffer = new byte[dataGramPacket.getLength()];
		System.arraycopy(dataGramPacket.getData(), dataGramPacket.getOffset(), buffer, 0, dataGramPacket.getLength());
		//DnsPacket����������
		try {
			dnsPacket.parsePacket(buffer);
		} catch (IOException e) {
			System.out.println("����DNS���ĳ��� "+e.getMessage());
			e.printStackTrace();
		}
		//����������ͨ��
		if(connector.getFilter() != null) {
			if(connector.getFilter().accpet(dnsPacket, response)) {
				//�첽��������
				connector.assign(dnsPacket, response);
			}
		}
		else {
			//�첽��������
			connector.assign(dnsPacket, response);
		}
	}	
}
