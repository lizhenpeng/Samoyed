package com.lizhenpeng.samoyed.core;

import java.util.HashMap;

import com.lizhenpeng.samoyed.util.Processer;
import com.lizhenpeng.samoyed.util.RecordType;

public class Router {
	
	//------------------------------------------------------------------------ Instance Variables
	
	private static Router router;
	private static final Object Lock = new Object();
	private static HashMap<RecordType,Class<? extends Processer>> hash = new HashMap<>();
	
	//------------------------------------------------------------------------ Public Methods
	
	private Router() {
		//˽�еĹ��캯��
	}
	
	public static Router getInstance() {
		synchronized(Lock) {
			if(router == null) {
				router = new Router();
			}
			return router;
		}
	}
	
	public synchronized void registerProcessor(RecordType type,Class<? extends Processer> processer) {
		hash.put(type, processer);
	}
	
	public synchronized void removeProcesser(RecordType type) {
		hash.remove(type);
	} 
	
	public Class<? extends Processer> getProcesser(RecordType type) {
		if(hash.containsKey(type)) {
			return hash.get(type);
		}
		return null;
	}
	
	public boolean contains(RecordType type) {
		return hash.containsKey(type);
	}
	
}
