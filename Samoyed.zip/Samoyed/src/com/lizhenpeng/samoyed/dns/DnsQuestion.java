package com.lizhenpeng.samoyed.dns;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class DnsQuestion {
	
	//------------------------------------------------------------------------- Instance Variables
	
	private byte[] QNAME; //�ֽ��������̶�,len+data���뷽ʽ,����:0x03wwww0X05baidu0x03com0x00!!!0x00��ʾ��β
	private short QTYPE; //Dns��ѯ������,A,CNAME,NS,MX�ȵ�
	private short QCLASS; //��ʾ��¼�ķ���һ��Ϊ1��ʾ��������Դ
	private String domain; //��ѯ�������ַ�����ʾ
	
	//------------------------------------------------------------------------- Public Methods
	
	public byte[] getQNAME() {
		return QNAME;
	}
	
	public void setQNAME(byte[] qName) {
		QNAME = qName;
	}
	
	public short getQTYPE() {
		return QTYPE;
	}
	
	public void setQTYPE(int qTYPE) {
		QTYPE = (short) qTYPE;
	}
	
	public short getQCLASS() {
		return QCLASS;
	}
	
	public void setQCLASS(int qCLASS) {
		QCLASS = (short) qCLASS;
	}
	
	public void setDomain(String domain) {
		this.domain = domain;
	}
	
	public String getDomain() {
		return domain;
	}
	
	public byte[] toDataArray() throws IOException {
		ByteArrayOutputStream dataSource = new ByteArrayOutputStream();
		DataOutputStream outData = new DataOutputStream(dataSource);
		outData.write(QNAME);
		outData.writeShort(QTYPE);
		outData.writeShort(QCLASS);
		dataSource.close();
		outData.close();
		byte[] buffer = new byte[dataSource.toByteArray().length];
		System.arraycopy(dataSource.toByteArray(), 0, buffer, 0, buffer.length);
		return buffer;
	}
}
