package com.lizhenpeng.samoyed.dns;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class DnsCommon {

	// ------------------------------------------------------------------------ Instance Variables

	private byte[] NAME; //���Ȳ������������������ݿ�����ָ��(����ѹ���㷨)
	private short TYPE; //��ʾRR����,��A,CNAME,MX,NS�ȵ�
	private short CLASS; //��ʾRR�ķ���
	private int TTL; //��ʾ��RR����������
	private short RDLENGTH; //RDATA���ݵĳ���
	private int RDATA; //���ص�����

	// ------------------------------------------------------------------------ Properties

	public byte[] getNAME() {
		return NAME;
	}

	public void setNAME(byte[] name) {
		NAME = name;
	}

	public short getTYPE() {
		return TYPE;
	}

	public void setTYPE(int type) {
		TYPE = (byte) type;
	}

	public short getCLASS() {
		return CLASS;
	}

	public void setCLASS(int rrClass) {
		CLASS = (byte) rrClass;
	}

	public int getTTL() {
		return TTL;
	}

	public void setTTL(int ttl) {
		TTL = ttl;
	}

	public short getRDLENGTH() {
		return RDLENGTH;
	}

	public void setRDLENGTH(int rdlength) {
		RDLENGTH = (byte) rdlength;
	}

	public int getRDATA() {
		return RDATA;
	}
	
	public void setRDATA(int data) {
		RDATA = data;
	}

	public void setRDATA(String ipAddress) {
		String[] parts = ipAddress.split("\\.");
		int[] ip = new int[4];
		int value = 0;
		int index = 0;
		for(; index < parts.length; index++) {
			ip[index] = Integer.parseInt(parts[index]);
		}
		value = value | ip[0];
		value = value << 8;
		value = value | ip[1];
		value = value << 8;
		value = value | ip[2];
		value = value << 8;
		value = value | ip[3];
		RDATA = value;
	}
	
	public byte[] toDataArray() throws IOException {
		ByteArrayOutputStream dataSource = new ByteArrayOutputStream();
		DataOutputStream outData = new DataOutputStream(dataSource);
		outData.write(NAME);
		outData.writeShort(TYPE);
		outData.writeShort(CLASS);
		outData.writeInt(TTL);
		outData.writeShort(RDLENGTH);
		outData.writeInt(RDATA);
		outData.close();
		return dataSource.toByteArray();
	}
}
